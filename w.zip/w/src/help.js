

  𝘼𝙌𝙐𝙄 𝙑𝘼̃𝙊 𝙀𝙎𝙏𝘼́ 𝘼𝙇𝙂𝙐𝙉𝙎 𝘾𝙊𝙈𝘼𝙉𝘿𝙊𝙎:

➢【𝗠𝗘𝗟𝗛𝗢𝗥𝗘𝗦】

➛ *${prefix}Sticker* [Faz figurinha]
➛ *${prefix}play* [nome da música]
➛ *${prefix}toimg* [converter figurinha em imagem]
➛ *${prefix}meme* [memes aleatórios]

➢【𝗣𝗔𝗥𝗔 𝗚𝗥𝗨𝗣𝗢𝗦】

➛ *${prefix}marcar* [marcar todos membros]
➛ *${prefix}bemvindo* 1 [recusso de boas vindas]


➢【𝗜𝗡𝗧𝗘𝗥𝗔𝗚𝗜𝗥】
➛
➛ *${prefix}figu*
➛ *${prefix}toimg*
➛ *${prefix}lolih [on]*
➛ *${prefix}wait [na legenda]*

➢【 𝗜𝗠𝗔𝗚𝗘𝗡𝗦 】
➛
➛ *${prefix}loli* [off]
➛ *${prefix}loli1*
➛ *${prefix}hentai*
➛ *${prefix}dono*
➛ *${prefix}porno*
➛ *${prefix}boanoite*
➛ *${prefix}bomdia*
➛ *${prefix}boatarde*
➛ *${prefix}mia [aleatórias]*
➛ *${prefix}rize [aleatórias]*
➛ *${prefix}minato [aleatórias]*
➛ *${prefix}boruto [aleatórias]*
➛ *${prefix}hinata [aleatórias]*
➛ *${prefix}sasuke [aleatórias]*
➛ *${prefix}sakura [aleatórias]*
➛ *${prefix}naruto [aleatórias]*
➛ *${prefix}meme*   
➛ *${prefix}lofi*
➛ *${prefix}malkova*
➛ *${prefix}canal*
➛ *${prefix}nsfwloli1*
➛ *${prefix}reislin*

➢【𝗚𝗥𝗨𝗣𝗢】

➛ *${prefix}leveling [on/off]*
➛ *${prefix}level*
➛ *${prefix}setname [texto]*
➛ *${prefix}rebaixar*
➛ *${prefix}admins*
➛ *${prefix}marcar*
➛ *${prefix}marcar2*
➛ *${prefix}marcar3*
➛ *${prefix}bemvindo [1/0]*
➛ *${prefix}grupoinfo*
➛ *${prefix}bomdia*
➛ *${prefix}boatarde*
➛ *${prefix}boanoite*
➛ *${prefix}setdesc*
➛ *${prefix}bug [sua mensagem]*
【 WARRIORS 】
➢【 𝗖𝗢𝗠𝗔𝗡𝗗𝗢𝗦 𝗗𝗘 𝗠𝗨𝗦𝗜𝗖𝗔 】



➛ *${prefix}narutinho*
➛ *${prefix}}tobi*
➛ *${prefix}paypal*
➛ *${prefix}sad*
➛ *${prefix} *beat1*
➛ *${prefix} *beat2*

}

exports.help = help

















